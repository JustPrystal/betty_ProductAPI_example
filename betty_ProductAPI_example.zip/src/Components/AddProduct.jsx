import ProductAPI from "../FirebaseAPI/ProductAPI";
import { useMutation, useQueryClient } from "react-query";
import { useState } from "react";

const AddProduct = () => {
	const queryClient = useQueryClient();

	const [Data, setData] = useState(DefaultProject);

	console.log(Data)

	const AddProduct = async () =>{
		const {image, ...DataToUpload} = Data
		await ProductAPI.addProduct(
			DataToUpload,
			image
		);
	}
		

	const { mutate } = useMutation(AddProduct, {
		onSuccess: () => {
			setData(DefaultProject);
			queryClient.invalidateQueries("products");
		},
	});
	const UpdateValue = (e) => setData({ ...Data, [e.target.name]: e.target.value });

	return (
		<div className="AddProduct">
			<div className="AddProduct-wrapper">
				<input
					onChange={UpdateValue}
					type="text"
					name="heading"
					value={Data.heading}
					placeholder="Product heading"
				/>
				<input
					onChange={UpdateValue}
					type="text"
					name="subHeading"
					value={Data.subHeading}
					placeholder="Product subHeading"
				/>
				{/* <input
					onChange={UpdateValue}
					type="text"
					name="shortDescription"
					value={Data.shortDescription}
					placeholder="Product shortDescription"
				/> */}
				<input
					onChange={UpdateValue}
					type="text"
					name="macros"
					value={Data.macros}
					placeholder="Product Macros"
				/>
				<input
					onChange={UpdateValue}
					type="text"
					name="serving"
					value={Data.serving}
					placeholder="Product serving"
				/>
				<input
					onChange={UpdateValue}
					type="text"
					name="time"
					value={Data.time}
					placeholder="Product time"
				/>
				<input
					onChange={UpdateValue}
					type="text"
					name="calories"
					value={Data.calories}
					placeholder="Product calories"
				/> 

				<textarea name="direction" rows={3} cols={20} value={Data.direction} onChange={UpdateValue} placeholder="Product Direction" />

				<textarea name="nutrition" rows={3} cols={20} value={Data.nutrition} onChange={UpdateValue} placeholder="Product Nutrition" />

				<div className="mying">
					{Data.ingredients.map(x => {
						return <div className="ing">
							<div className="Unit">{x.Ingval}</div>
							<div className="title">{x.Ingname}</div>
							<div className="desc">{x.Ingunit}</div>
						</div>
					})}
				</div>

				<Ingredients addIng={(newData) => setData({ ...Data, ingredients: [...Data.ingredients, newData] })} />
				<input 
					type="file"
					onChange={
						({ target }) => setData({ ...Data, image: target.files[0] })
					}
				/>
				<div className="categories">
					<button onClick={() => setData({...Data, category: "breakfast" })}>Breakfast</button>
					<button onClick={() => setData({...Data, category: "lunch" })}>lunch</button>
					<button onClick={() => setData({...Data, category: "dinner" })}>dinner</button>
				</div>
				<button onClick={mutate}>Add product</button>
			</div>
		</div>
	);
};

const Ingredients = ({ addIng }) => {
	const [SingleIng, setSingleIng] = useState({ Ingval:"", Ingname: "", Ingunit: "" }) 
	const UpdateValue = (e) => setSingleIng({ ...SingleIng, [e.target.name]: e.target.value });

	const submit = () => {
		addIng(SingleIng)
		setSingleIng({ Ingval:"", Ingname: "", Ingunit: "" })
	}
	return (
		<div className="ING">
			<input type="text" name="Ingname" value={SingleIng.Ingname}  onChange={UpdateValue} placeholder="IngName"/>
			<input type="text" name="Ingval" value={SingleIng.Ingval} onChange={UpdateValue} placeholder="Ingvalue"/> 
			<select name="Ingunit" value={SingleIng.Ingunit}  onChange={UpdateValue}>
				<option>Select Unit</option>
				<option value="c">Cup</option>
				<option value="Tbsp">Tbsp</option>
				<option value="oz">Oz</option>
				<option value="serving">Serving</option>
				<option value="grams">Grams</option>
			</select>
			<button onClick={submit}>Add Ingredients</button>
		</div>
	);
	
}

const DefaultProject = {
	heading: "",
	subHeading: "",
	// shortDescription: "",
	ingredients: [],
	macros:"",
	serving: "",
	time: "",
	calories: "",
	direction:"",
	nutrition:"",
	image: "",
	category: "",
};

export default AddProduct;
