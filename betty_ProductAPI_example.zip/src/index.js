import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./Sass/style.scss";

const root = ReactDOM.createRoot(document.getElementById("BETTY_APP"));
root.render(<App />);
